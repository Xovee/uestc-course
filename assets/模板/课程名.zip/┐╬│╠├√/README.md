# 具体课程名，例如：微积分

课程介绍。

## 下载

[点击该链接，下载本文件夹所有内容](https://xovee.github.io/gitzip/?https://github.com/UESTC-Course/uestc-course/tree/master/课程目录/[课程名])

**请将上面链接中方括号内中的课程名替换为真实的课程名**，例如：

> \[点击该链接，下载本文件夹所有内容\](https://xovee.github.io/gitzip/?https://github.com/UESTC-Course/uestc-course/tree/master/课程目录/[课程名])
> 
> 替换为
>
> \[点击该链接，下载本文件夹所有内容\](https://xovee.github.io/gitzip/?https://github.com/UESTC-Course/uestc-course/tree/master/课程目录/微积分)

## 相关课程（可选）

（此处描述与本课程相关的其他课程，包括但不限于本课程的历史课程名，内容相似的课程文件夹超链接等。）

## 开课历史

老师名|开课学院|开课年份|
---|---|---
老师A|信息与软件工程学院|2010-2016, 2019
老师B|信息与通信工程学院|2016-2018
老师C、老师D|电子科学与工程学院|2017
